package th.donut;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.*;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

public class DonutSMP extends JavaPlugin implements Listener, TabExecutor {

    // ---------- โครงสร้างข้อมูล ----------
    static class Gui implements InventoryHolder {
        final String type;
        Inventory inv;
        int page;
        List<Order> orders = new ArrayList<>();
        List<Listing> shown = new ArrayList<>();
        Gui(String type) { this.type = type; }
        @Override public Inventory getInventory() { return inv; }
    }

    static class Order {
        final int id; final UUID owner; final Material mat; int left; final double price;
        Order(int id, UUID owner, Material mat, int left, double price) {
            this.id = id; this.owner = owner; this.mat = mat; this.left = left; this.price = price;
        }
    }

    static class Listing {
        final int id; final UUID seller; final ItemStack item; final double price; final long time;
        Listing(int id, UUID seller, ItemStack item, double price, long time) {
            this.id = id; this.seller = seller; this.item = item; this.price = price; this.time = time;
        }
    }

    static class TpaReq {
        final UUID from; final boolean here; final long expire;
        TpaReq(UUID from, boolean here, long expire) { this.from = from; this.here = here; this.expire = expire; }
    }

    private final Map<UUID, Double> money = new HashMap<>();
    private final Map<UUID, Long> shards = new HashMap<>();
    private final Map<UUID, Long> playSeconds = new HashMap<>();
    private final List<Order> orders = new ArrayList<>();
    private final List<Listing> listings = new ArrayList<>();
    private final Map<UUID, Map<String, Integer>> claims = new HashMap<>();
    private final Map<UUID, Long> rtpCooldown = new HashMap<>();
    private final Map<UUID, TpaReq> tpaReqs = new HashMap<>();
    private final Map<UUID, String> teamInvites = new HashMap<>();
    private int nextOrderId = 1;
    private int nextListingId = 1;
    private long keyallNext;
    private File dataFile;
    private YamlConfiguration data;

    // ---------- เปิด/ปิดปลั๊กอิน ----------
    @Override
    public void onEnable() {
        // ถ้า config เก่า (เวอร์ชันต่ำกว่า 2) ให้ย้ายไปเป็น config-old.yml แล้วสร้างใหม่
        File cf = new File(getDataFolder(), "config.yml");
        if (cf.exists() && YamlConfiguration.loadConfiguration(cf).getInt("config-version", 1) < 2) {
            File old = new File(getDataFolder(), "config-old.yml");
            if (old.exists()) old.delete();
            cf.renameTo(old);
        }
        saveDefaultConfig();
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        for (String name : List.of("shop", "sell", "order", "ah", "rtp", "sethome", "home", "delhome", "homes",
                "balance", "pay", "tpa", "tphere", "tpaccept", "tpdeny", "tpauto", "settings", "nv", "team", "eco")) {
            PluginCommand pc = getCommand(name);
            if (pc != null) { pc.setExecutor(this); pc.setTabCompleter(this); }
        }
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, this::saveData, 6000L, 6000L);
        Bukkit.getOnlinePlayers().forEach(this::setupBoard);
    }

    @Override
    public void onDisable() { saveData(); }

    void tick() {
        long now = System.currentTimeMillis();
        if (now >= keyallNext) {
            keyall();
            keyallNext = now + keyallInterval();
        }
        long per = getConfig().getLong("shards.per-minutes", 10) * 60;
        long amt = getConfig().getLong("shards.amount", 1);
        for (Player p : Bukkit.getOnlinePlayers()) {
            long t = playSeconds.merge(p.getUniqueId(), 1L, Long::sum);
            if (per > 0 && t % per == 0) {
                shards.merge(p.getUniqueId(), amt, Long::sum);
                msg(p, "&dคุณได้รับ &f" + amt + " &dShards จากการเล่น!");
            }
            updateBoard(p);
        }
    }

    long keyallInterval() { return Math.max(1, getConfig().getLong("keyall.interval-minutes", 60)) * 60_000L; }

    void keyall() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            msg(p, "&9&lKEYALL! &fทุกคนได้รับรางวัลแล้ว");
            for (String cmd : getConfig().getStringList("keyall.commands"))
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", p.getName()));
        }
    }

    // ---------- Utility ----------
    String c(String s) { return ChatColor.translateAlternateColorCodes('&', s); }

    void msg(CommandSender s, String m) { s.sendMessage(c(getConfig().getString("prefix", "") + m)); }

    double bal(UUID id) { return money.getOrDefault(id, 0.0); }

    void add(UUID id, double amt) { money.put(id, Math.max(0, bal(id) + amt)); }

    boolean take(UUID id, double amt) {
        if (bal(id) < amt) return false;
        money.put(id, bal(id) - amt);
        return true;
    }

    static String fmt(double v) {
        String[] suf = {"", "K", "M", "B", "T"};
        int i = 0;
        while (v >= 1000 && i < suf.length - 1) { v /= 1000; i++; }
        if (i == 0) return v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.1f", v);
        String s = String.format(Locale.US, "%.1f", v);
        if (s.endsWith(".0")) s = s.substring(0, s.length() - 2);
        return s + suf[i];
    }

    static String hms(long s) { return (s / 3600) + "h " + (s % 3600 / 60) + "m " + (s % 60) + "s"; }

    static String shortTime(long s) {
        long h = s / 3600, m = s % 3600 / 60, x = s % 60;
        return h > 0 ? h + "h " + m + "m " + x + "s" : m + "m " + x + "s";
    }

    double parseAmount(String s) {
        try {
            s = s.toLowerCase(Locale.ROOT).replace(",", "");
            double mul = 1;
            if (s.endsWith("k")) mul = 1e3;
            else if (s.endsWith("m")) mul = 1e6;
            else if (s.endsWith("b")) mul = 1e9;
            if (mul != 1) s = s.substring(0, s.length() - 1);
            double v = Double.parseDouble(s) * mul;
            return (Double.isNaN(v) || Double.isInfinite(v)) ? -1 : v;
        } catch (Exception e) { return -1; }
    }

    void give(Player p, ItemStack it) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(it);
        left.values().forEach(r -> p.getWorld().dropItemNaturally(p.getLocation(), r));
    }

    ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta mt = it.getItemMeta();
        mt.setDisplayName(c(name));
        if (lore.length > 0) mt.setLore(Arrays.stream(lore).map(this::c).collect(Collectors.toList()));
        it.setItemMeta(mt);
        return it;
    }

    boolean setting(UUID id, String key, boolean def) { return data.getBoolean("settings." + id + "." + key, def); }

    void setSetting(UUID id, String key, boolean v) { data.set("settings." + id + "." + key, v); }

    List<String> names(String prefix) {
        return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))).collect(Collectors.toList());
    }

    double sellPrice(Material m) { return getConfig().getDouble("sell." + m.name(), getConfig().getDouble("sell-default", 1)); }

    // ---------- เก็บข้อมูล ----------
    void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection m = data.getConfigurationSection("money");
        if (m != null) for (String k : m.getKeys(false)) money.put(UUID.fromString(k), m.getDouble(k));
        ConfigurationSection sh = data.getConfigurationSection("shards");
        if (sh != null) for (String k : sh.getKeys(false)) shards.put(UUID.fromString(k), sh.getLong(k));
        ConfigurationSection pt = data.getConfigurationSection("playtime");
        if (pt != null) for (String k : pt.getKeys(false)) playSeconds.put(UUID.fromString(k), pt.getLong(k));
        ConfigurationSection os = data.getConfigurationSection("orders");
        if (os != null) for (String k : os.getKeys(false)) {
            ConfigurationSection s = os.getConfigurationSection(k);
            Material mat = Material.matchMaterial(s.getString("item", ""));
            if (mat == null) continue;
            int id = Integer.parseInt(k);
            orders.add(new Order(id, UUID.fromString(s.getString("owner")), mat, s.getInt("left"), s.getDouble("price")));
            nextOrderId = Math.max(nextOrderId, id + 1);
        }
        ConfigurationSection as = data.getConfigurationSection("auctions");
        if (as != null) for (String k : as.getKeys(false)) {
            ConfigurationSection s = as.getConfigurationSection(k);
            ItemStack it = s.getItemStack("item");
            if (it == null) continue;
            int id = Integer.parseInt(k);
            listings.add(new Listing(id, UUID.fromString(s.getString("seller")), it, s.getDouble("price"), s.getLong("time")));
            nextListingId = Math.max(nextListingId, id + 1);
        }
        ConfigurationSection cs = data.getConfigurationSection("claims");
        if (cs != null) for (String owner : cs.getKeys(false)) {
            Map<String, Integer> map = new HashMap<>();
            ConfigurationSection items = cs.getConfigurationSection(owner);
            for (String mat : items.getKeys(false)) map.put(mat, items.getInt(mat));
            claims.put(UUID.fromString(owner), map);
        }
        keyallNext = data.getLong("keyall.next", 0);
        if (keyallNext <= System.currentTimeMillis()) keyallNext = System.currentTimeMillis() + keyallInterval();
    }

    void saveData() {
        data.set("money", null);
        money.forEach((k, v) -> data.set("money." + k, v));
        data.set("shards", null);
        shards.forEach((k, v) -> data.set("shards." + k, v));
        data.set("playtime", null);
        playSeconds.forEach((k, v) -> data.set("playtime." + k, v));
        data.set("orders", null);
        for (Order o : orders) {
            String p = "orders." + o.id + ".";
            data.set(p + "owner", o.owner.toString());
            data.set(p + "item", o.mat.name());
            data.set(p + "left", o.left);
            data.set(p + "price", o.price);
        }
        data.set("auctions", null);
        for (Listing l : listings) {
            String p = "auctions." + l.id + ".";
            data.set(p + "seller", l.seller.toString());
            data.set(p + "item", l.item);
            data.set(p + "price", l.price);
            data.set(p + "time", l.time);
        }
        data.set("claims", null);
        claims.forEach((k, map) -> map.forEach((mat, n) -> data.set("claims." + k + "." + mat, n)));
        data.set("keyall.next", keyallNext);
        try { data.save(dataFile); } catch (IOException e) { getLogger().warning("save failed: " + e.getMessage()); }
    }

    // ---------- Scoreboard ----------
    String teamName(UUID id) {
        String key = data.getString("playerTeam." + id);
        if (key == null) return "none";
        return data.getString("teams." + key + ".name", "none");
    }

    void setupBoard(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective o = sb.registerNewObjective("donut", Criteria.DUMMY, c(getConfig().getString("scoreboard.title", "DONUT SMP")));
        o.setDisplaySlot(DisplaySlot.SIDEBAR);
        int n = Math.min(15, getConfig().getStringList("scoreboard.lines").size());
        for (int i = 0; i < n; i++) {
            Team t = sb.registerNewTeam("l" + i);
            String entry = "§" + Integer.toHexString(i) + "§r";
            t.addEntry(entry);
            o.getScore(entry).setScore(n - i);
        }
        p.setScoreboard(sb);
        updateBoard(p);
    }

    void updateBoard(Player p) {
        UUID id = p.getUniqueId();
        if (!setting(id, "scoreboard", true)) {
            if (p.getScoreboard().getObjective("donut") != null) p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            return;
        }
        Scoreboard sb = p.getScoreboard();
        if (sb.getObjective("donut") == null) { setupBoard(p); return; }
        List<String> lines = getConfig().getStringList("scoreboard.lines");
        long keyLeft = Math.max(0, (keyallNext - System.currentTimeMillis()) / 1000);
        for (int i = 0; i < Math.min(15, lines.size()); i++) {
            Team t = sb.getTeam("l" + i);
            if (t == null) continue;
            String line = lines.get(i)
                    .replace("{money}", fmt(bal(id)))
                    .replace("{shards}", fmt(shards.getOrDefault(id, 0L)))
                    .replace("{kills}", String.valueOf(p.getStatistic(Statistic.PLAYER_KILLS)))
                    .replace("{deaths}", String.valueOf(p.getStatistic(Statistic.DEATHS)))
                    .replace("{keyall}", shortTime(keyLeft))
                    .replace("{playtime}", hms(playSeconds.getOrDefault(id, 0L)))
                    .replace("{team}", teamName(id))
                    .replace("{player}", p.getName())
                    .replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()));
            t.setPrefix(c(line));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!money.containsKey(p.getUniqueId())) money.put(p.getUniqueId(), getConfig().getDouble("start-money", 0));
        setupBoard(p);
    }

    // ---------- คำสั่ง ----------
    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);

        if (n.equals("eco")) {
            if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cไม่มีสิทธิ์"); return true; }
            if (a.length < 3) { msg(s, "&e/eco <give|set|take> <player> <amount>"); return true; }
            OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]);
            double amt = parseAmount(a[2]);
            if (amt < 0) { msg(s, "&cจำนวนไม่ถูกต้อง"); return true; }
            switch (a[0].toLowerCase(Locale.ROOT)) {
                case "give" -> add(t.getUniqueId(), amt);
                case "take" -> add(t.getUniqueId(), -amt);
                case "set" -> money.put(t.getUniqueId(), amt);
                default -> { msg(s, "&cใช้ give/set/take"); return true; }
            }
            msg(s, "&aเงินของ " + a[1] + " ตอนนี้ $" + fmt(bal(t.getUniqueId())));
            return true;
        }

        if (!(s instanceof Player p)) { s.sendMessage("เฉพาะผู้เล่นเท่านั้น"); return true; }
        UUID id = p.getUniqueId();

        switch (n) {
            case "shop" -> openShop(p);
            case "sell" -> openSell(p);
            case "order" -> orderCmd(p, a);
            case "ah" -> ahCmd(p, a);
            case "rtp" -> rtpCmd(p, a);
            case "balance" -> msg(p, "&eเงินของคุณ: &a$" + fmt(bal(id)));
            case "pay" -> pay(p, a);
            case "tpa" -> tpaCmd(p, a, false);
            case "tphere" -> tpaCmd(p, a, true);
            case "tpaccept" -> tpRespond(p, true);
            case "tpdeny" -> tpRespond(p, false);
            case "tpauto" -> {
                boolean v = !setting(id, "tpauto", false);
                setSetting(id, "tpauto", v);
                msg(p, "&eรับ TPA อัตโนมัติ: " + (v ? "&aเปิด" : "&cปิด"));
            }
            case "settings" -> openSettings(p);
            case "nv" -> {
                if (p.hasPotionEffect(PotionEffectType.NIGHT_VISION)) {
                    p.removePotionEffect(PotionEffectType.NIGHT_VISION);
                    msg(p, "&eมองเห็นกลางคืน: &cปิด");
                } else {
                    p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, PotionEffect.INFINITE_DURATION, 0, false, false, false));
                    msg(p, "&eมองเห็นกลางคืน: &aเปิด");
                }
            }
            case "team" -> teamCmd(p, a);
            case "sethome" -> {
                String name = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "home";
                String base = "homes." + id;
                ConfigurationSection hs = data.getConfigurationSection(base);
                int count = hs == null ? 0 : hs.getKeys(false).size();
                boolean exists = hs != null && hs.contains(name);
                if (!exists && count >= getConfig().getInt("homes.max", 3)) { msg(p, "&cคุณตั้งบ้านได้สูงสุด " + getConfig().getInt("homes.max", 3) + " หลัง"); return true; }
                data.set(base + "." + name, p.getLocation());
                msg(p, "&aตั้งบ้าน &e" + name + " &aแล้ว");
            }
            case "home" -> {
                String name = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "home";
                Location l = data.getLocation("homes." + id + "." + name);
                if (l == null) { msg(p, "&cไม่พบบ้านชื่อ " + name); return true; }
                p.teleportAsync(l);
                msg(p, "&aวาปไปบ้าน &e" + name);
            }
            case "delhome" -> {
                if (a.length < 1) { msg(p, "&e/delhome <name>"); return true; }
                String path = "homes." + id + "." + a[0].toLowerCase(Locale.ROOT);
                if (!data.contains(path)) { msg(p, "&cไม่พบบ้านนี้"); return true; }
                data.set(path, null);
                msg(p, "&aลบบ้านแล้ว");
            }
            case "homes" -> {
                ConfigurationSection hs = data.getConfigurationSection("homes." + id);
                msg(p, "&eบ้านของคุณ: &f" + (hs == null || hs.getKeys(false).isEmpty() ? "ไม่มี" : String.join(", ", hs.getKeys(false))));
            }
        }
        return true;
    }

    void pay(Player p, String[] a) {
        if (a.length < 2) { msg(p, "&e/pay <player> <amount>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        double amt = parseAmount(a[1]);
        if (t == null || t == p) { msg(p, "&cไม่พบผู้เล่น"); return; }
        if (amt <= 0) { msg(p, "&cจำนวนไม่ถูกต้อง"); return; }
        if (!take(p.getUniqueId(), amt)) { msg(p, "&cเงินไม่พอ"); return; }
        add(t.getUniqueId(), amt);
        msg(p, "&aโอน $" + fmt(amt) + " ให้ " + t.getName());
        msg(t, "&aได้รับ $" + fmt(amt) + " จาก " + p.getName());
    }

    // ---------- TPA ----------
    void tpaCmd(Player p, String[] a, boolean here) {
        if (a.length < 1) { msg(p, "&e/" + (here ? "tphere" : "tpa") + " <player>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null || t == p) { msg(p, "&cไม่พบผู้เล่น"); return; }
        if (!setting(t.getUniqueId(), "tpa", true)) { msg(p, "&cผู้เล่นนี้ปิดรับคำขอวาป"); return; }
        if (setting(t.getUniqueId(), "tpauto", false)) { doTp(p, t, here); return; }
        tpaReqs.put(t.getUniqueId(), new TpaReq(p.getUniqueId(), here, System.currentTimeMillis() + 60_000));
        msg(p, "&aส่งคำขอไปยัง &e" + t.getName() + " &aแล้ว (หมดอายุใน 60 วินาที)");
        msg(t, "&e" + p.getName() + " &fขอ" + (here ? "ให้คุณวาปไปหาเขา" : "วาปมาหาคุณ") + " &7- พิมพ์ &a/tpaccept &7หรือ &c/tpdeny");
    }

    void doTp(Player requester, Player target, boolean here) {
        if (here) {
            target.teleportAsync(requester.getLocation());
            msg(target, "&aวาปไปหา &e" + requester.getName());
            msg(requester, "&e" + target.getName() + " &aวาปมาหาคุณแล้ว");
        } else {
            requester.teleportAsync(target.getLocation());
            msg(requester, "&aวาปไปหา &e" + target.getName());
            msg(target, "&e" + requester.getName() + " &aวาปมาหาคุณแล้ว");
        }
    }

    void tpRespond(Player p, boolean accept) {
        TpaReq r = tpaReqs.remove(p.getUniqueId());
        if (r == null || r.expire < System.currentTimeMillis()) { msg(p, "&cไม่มีคำขอวาปที่รออยู่"); return; }
        Player from = Bukkit.getPlayer(r.from);
        if (from == null) { msg(p, "&cผู้ขอออฟไลน์แล้ว"); return; }
        if (!accept) {
            msg(p, "&cปฏิเสธคำขอแล้ว");
            msg(from, "&c" + p.getName() + " ปฏิเสธคำขอวาปของคุณ");
            return;
        }
        doTp(from, p, r.here);
    }

    // ---------- /settings ----------
    private static final String[][] SETTINGS = {
            {"scoreboard", "แสดงสกอร์บอร์ด", "true"},
            {"tpauto", "รับ TPA อัตโนมัติ", "false"},
            {"tpa", "รับคำขอ TPA/TPHERE", "true"}};
    private static final int[] SETTING_SLOTS = {11, 13, 15};

    void openSettings(Player p) {
        Gui g = new Gui("settings");
        g.inv = Bukkit.createInventory(g, 27, c("&8&lตั้งค่า"));
        for (int i = 0; i < SETTINGS.length; i++) {
            boolean on = setting(p.getUniqueId(), SETTINGS[i][0], Boolean.parseBoolean(SETTINGS[i][2]));
            g.inv.setItem(SETTING_SLOTS[i], item(on ? Material.LIME_DYE : Material.GRAY_DYE,
                    (on ? "&a" : "&c") + SETTINGS[i][1] + ": " + (on ? "เปิด" : "ปิด"), "&7คลิกเพื่อสลับ"));
        }
        p.openInventory(g.inv);
    }

    // ---------- Team ----------
    void teamCmd(Player p, String[] a) {
        UUID id = p.getUniqueId();
        if (a.length == 0) { msg(p, "&e/team create <ชื่อ> | invite <ผู้เล่น> | accept | leave | info"); return; }
        String cur = data.getString("playerTeam." + id);
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (cur != null) { msg(p, "&cคุณอยู่ในทีมแล้ว"); return; }
                if (a.length < 2 || !a[1].matches("[A-Za-z0-9_]{2,12}")) { msg(p, "&e/team create <ชื่อ> &7(A-Z 0-9 _ ยาว 2-12 ตัว)"); return; }
                String key = a[1].toLowerCase(Locale.ROOT);
                if (data.contains("teams." + key)) { msg(p, "&cชื่อทีมนี้ถูกใช้แล้ว"); return; }
                data.set("teams." + key + ".name", a[1]);
                data.set("teams." + key + ".leader", id.toString());
                data.set("teams." + key + ".members", new ArrayList<>(List.of(id.toString())));
                data.set("playerTeam." + id, key);
                msg(p, "&aสร้างทีม &e" + a[1] + " &aแล้ว");
            }
            case "invite" -> {
                if (cur == null) { msg(p, "&cคุณยังไม่มีทีม"); return; }
                if (a.length < 2) { msg(p, "&e/team invite <ผู้เล่น>"); return; }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null || t == p) { msg(p, "&cไม่พบผู้เล่น"); return; }
                if (data.getString("playerTeam." + t.getUniqueId()) != null) { msg(p, "&cผู้เล่นนี้มีทีมแล้ว"); return; }
                teamInvites.put(t.getUniqueId(), cur);
                msg(p, "&aเชิญ &e" + t.getName() + " &aแล้ว");
                msg(t, "&e" + p.getName() + " &fเชิญคุณเข้าทีม &e" + teamName(id) + " &7- พิมพ์ &a/team accept");
            }
            case "accept" -> {
                String key = teamInvites.remove(id);
                if (key == null || !data.contains("teams." + key)) { msg(p, "&cไม่มีคำเชิญ"); return; }
                if (cur != null) { msg(p, "&cคุณอยู่ในทีมแล้ว"); return; }
                List<String> members = data.getStringList("teams." + key + ".members");
                if (members.size() >= getConfig().getInt("team.max-members", 5)) { msg(p, "&cทีมเต็มแล้ว"); return; }
                members.add(id.toString());
                data.set("teams." + key + ".members", members);
                data.set("playerTeam." + id, key);
                msg(p, "&aเข้าร่วมทีม &e" + data.getString("teams." + key + ".name"));
            }
            case "leave" -> {
                if (cur == null) { msg(p, "&cคุณไม่มีทีม"); return; }
                List<String> members = data.getStringList("teams." + cur + ".members");
                if (id.toString().equals(data.getString("teams." + cur + ".leader"))) {
                    for (String m : members) data.set("playerTeam." + m, null);
                    data.set("teams." + cur, null);
                    msg(p, "&eคุณเป็นหัวหน้า ทีมถูกยุบแล้ว");
                } else {
                    members.remove(id.toString());
                    data.set("teams." + cur + ".members", members);
                    data.set("playerTeam." + id, null);
                    msg(p, "&eออกจากทีมแล้ว");
                }
            }
            case "info" -> {
                if (cur == null) { msg(p, "&cคุณไม่มีทีม"); return; }
                String names = data.getStringList("teams." + cur + ".members").stream()
                        .map(u -> Optional.ofNullable(Bukkit.getOfflinePlayer(UUID.fromString(u)).getName()).orElse("?"))
                        .collect(Collectors.joining(", "));
                msg(p, "&eทีม &f" + teamName(id) + " &7| สมาชิก: &f" + names);
            }
            default -> msg(p, "&e/team create | invite | accept | leave | info");
        }
    }

    // ---------- /shop ----------
    void openShop(Player p) {
        Gui g = new Gui("shop");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("shop-title")));
        ConfigurationSection s = getConfig().getConfigurationSection("shop");
        if (s != null) for (String key : s.getKeys(false)) {
            Material m = Material.matchMaterial(key);
            if (m == null || !m.isItem()) continue;
            ItemStack it = new ItemStack(m);
            ItemMeta meta = it.getItemMeta();
            meta.setLore(List.of(c("&7ราคา: &a$" + fmt(s.getDouble(key)) + " &7/ชิ้น"), c("&eคลิกซ้าย = ซื้อ 1"), c("&eShift+คลิก = ซื้อ 64")));
            it.setItemMeta(meta);
            g.inv.addItem(it);
        }
        p.openInventory(g.inv);
    }

    // ---------- /sell (ขายได้ทุกอย่าง) ----------
    void openSell(Player p) {
        Gui g = new Gui("sell");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("sell-title")));
        p.openInventory(g.inv);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g) || !g.type.equals("sell")) return;
        Player p = (Player) e.getPlayer();
        double total = 0;
        int sold = 0;
        for (ItemStack it : e.getInventory().getContents()) {
            if (it == null || it.getType().isAir()) continue;
            double price = sellPrice(it.getType());
            if (price > 0) { total += price * it.getAmount(); sold += it.getAmount(); }
            else give(p, it);
        }
        e.getInventory().clear();
        if (total > 0) {
            add(p.getUniqueId(), total);
            msg(p, "&aขาย " + sold + " ชิ้น ได้เงิน &e$" + fmt(total));
        }
    }

    // ---------- /order ----------
    void orderCmd(Player p, String[] a) {
        if (a.length == 0) { openOrders(p); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (a.length < 4) { msg(p, "&e/order create <item> <amount> <price ต่อชิ้น>"); return; }
                Material m = Material.matchMaterial(a[1]);
                int amt;
                try { amt = Integer.parseInt(a[2]); } catch (NumberFormatException ex) { amt = -1; }
                double price = parseAmount(a[3]);
                if (m == null || !m.isItem() || amt <= 0 || price <= 0) { msg(p, "&cข้อมูลไม่ถูกต้อง"); return; }
                double cost = amt * price;
                if (!take(p.getUniqueId(), cost)) { msg(p, "&cเงินไม่พอ (ต้องใช้ $" + fmt(cost) + ")"); return; }
                orders.add(new Order(nextOrderId++, p.getUniqueId(), m, amt, price));
                msg(p, "&aสร้างออเดอร์รับซื้อ " + m.name() + " x" + amt + " ราคา $" + fmt(price) + "/ชิ้น");
            }
            case "claim" -> {
                Map<String, Integer> map = claims.remove(p.getUniqueId());
                if (map == null || map.isEmpty()) { msg(p, "&cไม่มีของให้รับ"); return; }
                map.forEach((mat, n) -> {
                    Material m = Material.matchMaterial(mat);
                    if (m == null) return;
                    int left = n;
                    while (left > 0) {
                        int st = Math.min(left, m.getMaxStackSize());
                        give(p, new ItemStack(m, st));
                        left -= st;
                    }
                });
                msg(p, "&aรับของจากออเดอร์แล้ว");
            }
            default -> openOrders(p);
        }
    }

    void openOrders(Player p) {
        Gui g = new Gui("orders");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("order-title")));
        for (Order o : orders) {
            if (g.orders.size() >= 54) break;
            ItemStack it = new ItemStack(o.mat);
            ItemMeta meta = it.getItemMeta();
            String owner = Optional.ofNullable(Bukkit.getOfflinePlayer(o.owner).getName()).orElse("?");
            List<String> lore = new ArrayList<>(List.of(
                    c("&7ผู้สั่ง: &f" + owner),
                    c("&7ต้องการอีก: &f" + o.left),
                    c("&7ราคาต่อชิ้น: &a$" + fmt(o.price)),
                    c("&aคลิกซ้าย = ส่งของให้ออเดอร์นี้")));
            if (o.owner.equals(p.getUniqueId())) lore.add(c("&cคลิกขวา = ยกเลิก (คืนเงิน)"));
            meta.setLore(lore);
            it.setItemMeta(meta);
            g.inv.setItem(g.orders.size(), it);
            g.orders.add(o);
        }
        p.openInventory(g.inv);
    }

    void fillOrder(Player p, Order o) {
        if (o.owner.equals(p.getUniqueId())) { msg(p, "&cส่งของให้ออเดอร์ตัวเองไม่ได้"); return; }
        ItemStack[] cs = p.getInventory().getStorageContents();
        int have = 0;
        for (ItemStack it : cs) if (it != null && it.getType() == o.mat && !it.hasItemMeta()) have += it.getAmount();
        int n = Math.min(have, o.left);
        if (n <= 0) { msg(p, "&cคุณไม่มี " + o.mat.name()); return; }
        int rem = n;
        for (int i = 0; i < cs.length && rem > 0; i++) {
            ItemStack it = cs[i];
            if (it == null || it.getType() != o.mat || it.hasItemMeta()) continue;
            int t = Math.min(rem, it.getAmount());
            if (t == it.getAmount()) cs[i] = null; else it.setAmount(it.getAmount() - t);
            rem -= t;
        }
        p.getInventory().setStorageContents(cs);
        double pay = n * o.price;
        add(p.getUniqueId(), pay);
        claims.computeIfAbsent(o.owner, k -> new HashMap<>()).merge(o.mat.name(), n, Integer::sum);
        o.left -= n;
        if (o.left <= 0) orders.remove(o);
        msg(p, "&aส่ง " + n + " ชิ้น ได้เงิน &e$" + fmt(pay));
        Player owner = Bukkit.getPlayer(o.owner);
        if (owner != null) msg(owner, "&aมีคนส่ง " + o.mat.name() + " x" + n + " ให้ออเดอร์ของคุณ! พิมพ์ &e/order claim");
    }

    // ---------- /ah ----------
    void ahCmd(Player p, String[] a) {
        if (a.length >= 1 && a[0].equalsIgnoreCase("sell")) {
            if (a.length < 2) { msg(p, "&e/ah sell <ราคา> &7(ถือของที่จะขายไว้ในมือ)"); return; }
            double price = parseAmount(a[1]);
            ItemStack hand = p.getInventory().getItemInMainHand();
            if (price <= 0) { msg(p, "&cราคาไม่ถูกต้อง"); return; }
            if (hand == null || hand.getType().isAir()) { msg(p, "&cต้องถือของที่จะขายไว้ในมือ"); return; }
            long mine = listings.stream().filter(l -> l.seller.equals(p.getUniqueId())).count();
            if (mine >= getConfig().getInt("ah.max-listings", 10)) { msg(p, "&cลงขายได้สูงสุด " + getConfig().getInt("ah.max-listings", 10) + " รายการ"); return; }
            listings.add(new Listing(nextListingId++, p.getUniqueId(), hand.clone(), price, System.currentTimeMillis()));
            p.getInventory().setItemInMainHand(null);
            msg(p, "&aลงขาย &e" + hand.getType().name() + " x" + hand.getAmount() + " &aราคา &e$" + fmt(price));
            return;
        }
        openAh(p, 0);
    }

    void openAh(Player p, int page) {
        List<Listing> sorted = new ArrayList<>(listings);
        sorted.sort((x, y) -> Long.compare(y.time, x.time));
        int pages = Math.max(1, (sorted.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("ah");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&6&lAuction House &7(" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(sorted.size(), page * 45 + 45); i++) {
            Listing l = sorted.get(i);
            ItemStack d = l.item.clone();
            ItemMeta m = d.getItemMeta();
            List<String> lore = m.hasLore() && m.getLore() != null ? new ArrayList<>(m.getLore()) : new ArrayList<>();
            lore.add(c("&8──────────"));
            lore.add(c("&7ราคา: &a$" + fmt(l.price)));
            lore.add(c("&7ผู้ขาย: &f" + Optional.ofNullable(Bukkit.getOfflinePlayer(l.seller).getName()).orElse("?")));
            lore.add(c(l.seller.equals(p.getUniqueId()) ? "&cคลิกขวา = ยกเลิกการขาย" : "&aคลิกซ้าย = ซื้อ"));
            m.setLore(lore);
            d.setItemMeta(m);
            g.inv.setItem(g.shown.size(), d);
            g.shown.add(l);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« หน้าก่อนหน้า"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eหน้าถัดไป »"));
        g.inv.setItem(49, item(Material.PAPER, "&6วิธีลงขาย", "&7ถือของไว้ในมือแล้วพิมพ์", "&f/ah sell <ราคา>"));
        p.openInventory(g.inv);
    }

    void buyListing(Player p, Listing l) {
        if (l.seller.equals(p.getUniqueId())) { msg(p, "&cซื้อของตัวเองไม่ได้"); return; }
        if (!take(p.getUniqueId(), l.price)) { msg(p, "&cเงินไม่พอ (ต้องใช้ $" + fmt(l.price) + ")"); return; }
        listings.remove(l);
        add(l.seller, l.price);
        give(p, l.item.clone());
        msg(p, "&aซื้อ " + l.item.getType().name() + " x" + l.item.getAmount() + " ราคา &e$" + fmt(l.price));
        Player seller = Bukkit.getPlayer(l.seller);
        if (seller != null) msg(seller, "&a" + p.getName() + " ซื้อ " + l.item.getType().name() + " ของคุณ ได้เงิน &e$" + fmt(l.price));
    }

    // ---------- คลิก GUI ----------
    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder(false) instanceof Gui g && !g.type.equals("sell")) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g)) return;
        if (g.type.equals("sell")) return; // ให้วางของได้อิสระ
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        ItemStack it = e.getCurrentItem();
        if (it == null || it.getType().isAir()) return;
        Player p = (Player) e.getWhoClicked();
        int slot = e.getSlot();

        switch (g.type) {
            case "shop" -> {
                int amt = e.isShiftClick() ? 64 : 1;
                double price = getConfig().getDouble("shop." + it.getType().name(), -1);
                if (price < 0) return;
                double total = price * amt;
                if (!take(p.getUniqueId(), total)) { msg(p, "&cเงินไม่พอ (ต้องใช้ $" + fmt(total) + ")"); return; }
                give(p, new ItemStack(it.getType(), amt));
                msg(p, "&aซื้อ " + it.getType().name() + " x" + amt + " ราคา $" + fmt(total));
            }
            case "orders" -> {
                if (slot >= g.orders.size()) return;
                Order o = g.orders.get(slot);
                if (!orders.contains(o)) { openOrders(p); return; }
                if (e.isRightClick() && o.owner.equals(p.getUniqueId())) {
                    orders.remove(o);
                    add(p.getUniqueId(), o.left * o.price);
                    msg(p, "&aยกเลิกออเดอร์ คืนเงิน $" + fmt(o.left * o.price));
                } else if (e.isLeftClick()) {
                    fillOrder(p, o);
                }
                openOrders(p);
            }
            case "rtp" -> {
                World.Environment env = slot == 11 ? World.Environment.NORMAL
                        : slot == 13 ? World.Environment.NETHER
                        : slot == 15 ? World.Environment.THE_END : null;
                if (env == null) return;
                Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); rtp(p, env); });
            }
            case "settings" -> {
                for (int i = 0; i < SETTING_SLOTS.length; i++) {
                    if (SETTING_SLOTS[i] != slot) continue;
                    String key = SETTINGS[i][0];
                    boolean cur = setting(p.getUniqueId(), key, Boolean.parseBoolean(SETTINGS[i][2]));
                    setSetting(p.getUniqueId(), key, !cur);
                    break;
                }
                openSettings(p);
                updateBoard(p);
            }
            case "ah" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openAh(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openAh(p, g.page + 1); return; }
                if (slot >= g.shown.size()) return;
                Listing l = g.shown.get(slot);
                if (!listings.contains(l)) { openAh(p, g.page); return; }
                if (e.isRightClick() && l.seller.equals(p.getUniqueId())) {
                    listings.remove(l);
                    give(p, l.item.clone());
                    msg(p, "&eยกเลิกการขายแล้ว ได้ของคืน");
                } else if (e.isLeftClick()) {
                    buyListing(p, l);
                }
                openAh(p, g.page);
            }
        }
    }

    // ---------- /rtp ----------
    void rtpCmd(Player p, String[] a) {
        if (a.length == 0) { openRtp(p); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "overworld", "ow", "world", "normal" -> rtp(p, World.Environment.NORMAL);
            case "nether", "hell" -> rtp(p, World.Environment.NETHER);
            case "end", "the_end" -> rtp(p, World.Environment.THE_END);
            default -> openRtp(p);
        }
    }

    void openRtp(Player p) {
        Gui g = new Gui("rtp");
        g.inv = Bukkit.createInventory(g, 27, c("&8&lRTP - เลือกมิติ"));
        g.inv.setItem(11, item(Material.GRASS_BLOCK, "&aโอเวอร์เวิลด์", "&7คลิกเพื่อสุ่มวาป"));
        g.inv.setItem(13, item(Material.NETHERRACK, "&cเนเธอร์ (นรก)", "&7คลิกเพื่อสุ่มวาป"));
        g.inv.setItem(15, item(Material.END_STONE, "&dดิ เอนด์", "&7คลิกเพื่อสุ่มวาป"));
        p.openInventory(g.inv);
    }

    World findWorld(World.Environment env) {
        return Bukkit.getWorlds().stream().filter(w -> w.getEnvironment() == env).findFirst().orElse(null);
    }

    void rtp(Player p, World.Environment env) {
        long now = System.currentTimeMillis();
        long cd = getConfig().getLong("rtp.cooldown", 10) * 1000;
        Long last = rtpCooldown.get(p.getUniqueId());
        if (last != null && now - last < cd) { msg(p, "&cรออีก " + ((cd - (now - last)) / 1000 + 1) + " วินาที"); return; }
        World w = findWorld(env);
        if (w == null) { msg(p, "&cไม่พบโลกมิตินี้ในเซิร์ฟเวอร์"); return; }
        rtpCooldown.put(p.getUniqueId(), now);
        msg(p, "&eกำลังสุ่มตำแหน่ง...");
        tryRtp(p, w, 0, env == World.Environment.THE_END ? 80 : 20);
    }

    void tryRtp(Player p, World w, int tries, int maxTries) {
        if (tries >= maxTries) { msg(p, "&cหาตำแหน่งปลอดภัยไม่ได้ ลองใหม่อีกครั้ง"); rtpCooldown.remove(p.getUniqueId()); return; }
        String key = switch (w.getEnvironment()) { case NETHER -> "nether"; case THE_END -> "end"; default -> "overworld"; };
        int defMin = switch (key) { case "nether" -> 300; case "end" -> 1200; default -> 500; };
        int defMax = switch (key) { case "nether" -> 2500; case "end" -> 4000; default -> 5000; };
        Location ctr = w.getWorldBorder().getCenter();
        int max = (int) Math.min(getConfig().getInt("rtp." + key + ".max", defMax), w.getWorldBorder().getSize() / 2 - 16);
        int min = Math.min(getConfig().getInt("rtp." + key + ".min", defMin), max / 2);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = min + r.nextDouble() * (max - min);
        int x = (int) (ctr.getX() + Math.cos(ang) * dist);
        int z = (int) (ctr.getZ() + Math.sin(ang) * dist);
        w.getChunkAtAsync(x >> 4, z >> 4).thenAccept(ch -> Bukkit.getScheduler().runTask(this, () -> {
            if (!p.isOnline()) return;
            Location loc = findSafe(w, x, z);
            if (loc == null) { tryRtp(p, w, tries + 1, maxTries); return; }
            p.teleportAsync(loc).thenAccept(ok -> {
                if (ok) msg(p, "&aวาปแล้ว! &7X: " + x + " Z: " + z);
            });
        }));
    }

    Location findSafe(World w, int x, int z) {
        if (w.getEnvironment() == World.Environment.NETHER) {
            for (int y = 120; y >= 33; y--) {
                Block b = w.getBlockAt(x, y, z);
                if (isSafe(b)) return new Location(w, x + 0.5, y + 1, z + 0.5);
            }
            return null;
        }
        int y = w.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
        if (y < w.getMinHeight()) return null;
        Block b = w.getBlockAt(x, y, z);
        return isSafe(b) ? new Location(w, x + 0.5, y + 1, z + 0.5) : null;
    }

    boolean isSafe(Block b) {
        Material t = b.getType();
        if (!t.isSolid() || Tag.LEAVES.isTagged(t)) return false;
        switch (t) {
            case MAGMA_BLOCK, CACTUS, CAMPFIRE, SOUL_CAMPFIRE, POWDER_SNOW, SWEET_BERRY_BUSH,
                 WITHER_ROSE, CHORUS_PLANT, CHORUS_FLOWER, BEDROCK -> { return false; }
            default -> { }
        }
        for (int i = 1; i <= 2; i++) {
            Block a = b.getRelative(0, i, 0);
            Material at = a.getType();
            if (!a.isPassable() || a.isLiquid() || at == Material.FIRE || at == Material.SOUL_FIRE || at == Material.LAVA) return false;
        }
        return true;
    }

    // ---------- Tab complete ----------
    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);
        if ((n.equals("home") || n.equals("delhome")) && a.length == 1 && s instanceof Player p) {
            ConfigurationSection hs = data.getConfigurationSection("homes." + p.getUniqueId());
            return hs == null ? List.of() : hs.getKeys(false).stream().filter(k -> k.startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        if ((n.equals("pay") || n.equals("tpa") || n.equals("tphere")) && a.length == 1) return names(a[0]);
        if (n.equals("eco")) {
            if (a.length == 1) return List.of("give", "take", "set");
            if (a.length == 2) return names(a[1]);
        }
        if (n.equals("rtp") && a.length == 1) return List.of("overworld", "nether", "end");
        if (n.equals("ah") && a.length == 1) return List.of("sell");
        if (n.equals("team")) {
            if (a.length == 1) return List.of("create", "invite", "accept", "leave", "info");
            if (a.length == 2 && a[0].equalsIgnoreCase("invite")) return names(a[1]);
        }
        if (n.equals("order")) {
            if (a.length == 1) return List.of("create", "claim");
            if (a.length == 2 && a[0].equalsIgnoreCase("create"))
                return Arrays.stream(Material.values()).filter(Material::isItem).map(m -> m.name().toLowerCase(Locale.ROOT))
                        .filter(k -> k.startsWith(a[1].toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
        }
        return List.of();
    }
}
